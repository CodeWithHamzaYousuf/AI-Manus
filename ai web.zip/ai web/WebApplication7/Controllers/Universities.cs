﻿using Microsoft.AspNetCore.Mvc;

namespace WebApplication7.Controllers
{
    public class Universities : Controller
    {
        public IActionResult Index()
        {
            return View();
        }

        public IActionResult KU()
        {
            return View();
        }

        public IActionResult NED()
        {
            return View();
        }
        public IActionResult IBA()
        {
            return View();
        }

        public IActionResult IQRA()
        {
            return View();
        }

        public IActionResult DOW()
        {
            return View();
        }
        public IActionResult Agha()
        {
            return View();
        }
    }
}
