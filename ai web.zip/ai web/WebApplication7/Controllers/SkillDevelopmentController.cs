using Microsoft.AspNetCore.Mvc;

namespace WebApplication7.Controllers
{
    public class SkillDevelopmentController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }

        public IActionResult Programming()
        {
            return View();
        }

        public IActionResult Business()
        {
            return View();
        }

        public IActionResult Design()
        {
            return View();
        }

        public IActionResult Healthcare()
        {
            return View();
        }
    }
}

