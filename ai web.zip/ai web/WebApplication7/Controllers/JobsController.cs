using Microsoft.AspNetCore.Mvc;
using WebApplication7.Models;

namespace WebApplication7.Controllers
{
    public class JobsController : Controller
    {
        public IActionResult Index(string searchTerm = "", string location = "")
        {
            var jobs = GetSampleJobs();
            
            // Apply search filters
            if (!string.IsNullOrEmpty(searchTerm))
            {
                jobs = jobs.Where(j => 
                    j.Title.Contains(searchTerm, StringComparison.OrdinalIgnoreCase) ||
                    j.Company.Contains(searchTerm, StringComparison.OrdinalIgnoreCase) ||
                    j.Description.Contains(searchTerm, StringComparison.OrdinalIgnoreCase) ||
                    j.Requirements.Contains(searchTerm, StringComparison.OrdinalIgnoreCase)
                ).ToList();
            }
            
            if (!string.IsNullOrEmpty(location) && location != "All Locations")
            {
                jobs = jobs.Where(j => j.Location.Contains(location, StringComparison.OrdinalIgnoreCase)).ToList();
            }
            
            ViewBag.SearchTerm = searchTerm;
            ViewBag.Location = location;
            
            return View(jobs);
        }

        public IActionResult Details(int id)
        {
            var job = GetSampleJobs().FirstOrDefault(j => j.Id == id);
            if (job == null)
            {
                return NotFound();
            }
            return View(job);
        }

        public IActionResult Apply(int id)
        {
            var job = GetSampleJobs().FirstOrDefault(j => j.Id == id);
            if (job == null)
            {
                return NotFound();
            }
            return View(job);
        }

        [HttpPost]
        public IActionResult Apply(int id, string applicantName, string email, string resume)
        {
            // Logic to handle job application
            ViewBag.Message = "Application submitted successfully!";
            return View("ApplicationSuccess");
        }

        public IActionResult Tracker()
        {
            return View();
        }

        private List<JobListing> GetSampleJobs()
        {
            return new List<JobListing>
            {
                // BSSE - Software Engineering Jobs
                new JobListing
                {
                    Id = 1,
                    Title = "Senior Software Engineer",
                    Company = "Tech Solutions Ltd",
                    Location = "Karachi, Pakistan",
                    Type = "Full-time",
                    Salary = "PKR 120,000 - 180,000",
                    Description = "We are looking for a skilled software engineer with BSSE background to join our development team.",
                    Requirements = "BSSE degree, 3+ years experience in C#/.NET, software architecture knowledge",
                    PostedDate = DateTime.Now.AddDays(-5)
                },
                new JobListing
                {
                    Id = 2,
                    Title = "Software Architect",
                    Company = "Digital Innovations",
                    Location = "Lahore, Pakistan",
                    Type = "Full-time",
                    Salary = "PKR 200,000 - 300,000",
                    Description = "Lead software architecture and design for enterprise applications.",
                    Requirements = "BSSE/BSCS degree, 5+ years experience, system design expertise",
                    PostedDate = DateTime.Now.AddDays(-3)
                },
                
                // BSCS - Computer Science Jobs
                new JobListing
                {
                    Id = 3,
                    Title = "Data Scientist",
                    Company = "Analytics Corp",
                    Location = "Islamabad, Pakistan",
                    Type = "Full-time",
                    Salary = "PKR 100,000 - 150,000",
                    Description = "Analyze large datasets and build machine learning models.",
                    Requirements = "BSCS degree, Python/R proficiency, machine learning experience",
                    PostedDate = DateTime.Now.AddDays(-7)
                },
                new JobListing
                {
                    Id = 4,
                    Title = "Full Stack Developer",
                    Company = "Web Solutions Inc",
                    Location = "Karachi, Pakistan",
                    Type = "Full-time",
                    Salary = "PKR 80,000 - 120,000",
                    Description = "Develop web applications using modern frameworks and technologies.",
                    Requirements = "BSCS degree, JavaScript, React, Node.js experience",
                    PostedDate = DateTime.Now.AddDays(-2)
                },
                
                // BBA - Business Administration Jobs
                new JobListing
                {
                    Id = 5,
                    Title = "Business Analyst",
                    Company = "Financial Services Corp",
                    Location = "Islamabad, Pakistan",
                    Type = "Full-time",
                    Salary = "PKR 70,000 - 100,000",
                    Description = "Analyze business processes and recommend improvements.",
                    Requirements = "BBA degree, strong analytical skills, Excel proficiency",
                    PostedDate = DateTime.Now.AddDays(-4)
                },
                new JobListing
                {
                    Id = 6,
                    Title = "Marketing Manager",
                    Company = "Brand Solutions",
                    Location = "Lahore, Pakistan",
                    Type = "Full-time",
                    Salary = "PKR 90,000 - 130,000",
                    Description = "Lead marketing campaigns and brand development initiatives.",
                    Requirements = "BBA in Marketing, 3+ years experience, digital marketing skills",
                    PostedDate = DateTime.Now.AddDays(-6)
                },
                
                // BSME - Mechanical Engineering Jobs
                new JobListing
                {
                    Id = 7,
                    Title = "Mechanical Design Engineer",
                    Company = "Manufacturing Industries",
                    Location = "Faisalabad, Pakistan",
                    Type = "Full-time",
                    Salary = "PKR 75,000 - 110,000",
                    Description = "Design and oversee manufacturing processes and equipment.",
                    Requirements = "BSME degree, AutoCAD/SolidWorks skills, 2+ years experience",
                    PostedDate = DateTime.Now.AddDays(-8)
                },
                new JobListing
                {
                    Id = 8,
                    Title = "HVAC Engineer",
                    Company = "Climate Control Systems",
                    Location = "Karachi, Pakistan",
                    Type = "Full-time",
                    Salary = "PKR 85,000 - 125,000",
                    Description = "Design and maintain heating, ventilation, and air conditioning systems.",
                    Requirements = "BSME degree, HVAC design experience, thermodynamics knowledge",
                    PostedDate = DateTime.Now.AddDays(-1)
                },
                
                // BSFD - Fashion Design Jobs
                new JobListing
                {
                    Id = 9,
                    Title = "Fashion Designer",
                    Company = "Style Studio",
                    Location = "Lahore, Pakistan",
                    Type = "Full-time",
                    Salary = "PKR 60,000 - 90,000",
                    Description = "Create innovative fashion designs and oversee production.",
                    Requirements = "BSFD degree, portfolio required, fashion illustration skills",
                    PostedDate = DateTime.Now.AddDays(-5)
                },
                new JobListing
                {
                    Id = 10,
                    Title = "Textile Designer",
                    Company = "Fabric Innovations",
                    Location = "Faisalabad, Pakistan",
                    Type = "Full-time",
                    Salary = "PKR 55,000 - 80,000",
                    Description = "Design textile patterns and work with fabric development.",
                    Requirements = "BSFD degree, textile knowledge, design software proficiency",
                    PostedDate = DateTime.Now.AddDays(-9)
                },
                
                // MBBS - Medical Jobs
                new JobListing
                {
                    Id = 11,
                    Title = "Medical Officer",
                    Company = "City Hospital",
                    Location = "Karachi, Pakistan",
                    Type = "Full-time",
                    Salary = "PKR 150,000 - 200,000",
                    Description = "Provide medical care and consultation to patients.",
                    Requirements = "MBBS degree, valid medical license, 2+ years clinical experience",
                    PostedDate = DateTime.Now.AddDays(-3)
                },
                new JobListing
                {
                    Id = 12,
                    Title = "Emergency Medicine Physician",
                    Company = "Emergency Care Center",
                    Location = "Islamabad, Pakistan",
                    Type = "Full-time",
                    Salary = "PKR 180,000 - 250,000",
                    Description = "Provide emergency medical care in fast-paced environment.",
                    Requirements = "MBBS degree, emergency medicine training, BLS/ACLS certification",
                    PostedDate = DateTime.Now.AddDays(-2)
                }
            };
        }
    }
}

