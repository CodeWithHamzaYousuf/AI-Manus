﻿using Microsoft.AspNetCore.Mvc;

namespace WebApplication7.Controllers
{
    public class LoginController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}
