﻿namespace WebApplication7.Models
{
    public class QuizResponse
    {
        public int QuestionId { get; set; }
        public int SelectedOptionId { get; set; }
    }
}
