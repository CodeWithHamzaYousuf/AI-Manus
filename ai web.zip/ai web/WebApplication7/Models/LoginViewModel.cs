﻿namespace WebApplication7.Models
{
    public class LoginViewModel
    {
        public string Username { get; set; }
    }
}
